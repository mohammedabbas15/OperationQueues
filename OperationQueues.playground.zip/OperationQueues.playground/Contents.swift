import UIKit

//let operation = BlockOperation {
//    for i in 0...5 {
//        print(i)
//    }
//}
//
//let queue = OperationQueue()
//queue.addOperation(operation)

/*
struct Example {
    
    func doTask() {
        let blockOperation = BlockOperation()
        
        blockOperation.addExecutionBlock {
            print("Hello")
        }
        
        blockOperation.addExecutionBlock {
            print("My name is ")
        }
        
        blockOperation.addExecutionBlock {
            print("Swift")
        }
        
        let operationQ = OperationQueue()
        //operationQ.addOperation(blockOperation)
        
        let anotherBlockOperation = BlockOperation()
        anotherBlockOperation.addExecutionBlock {
            print("I am another block operation")
        }
        
        operationQ.addOperation(blockOperation)
        operationQ.addOperation(anotherBlockOperation)
    }
}

let objTest = Example()
objTest.doTask()
*/


// Adding Dependency
/*
 
struct Employee {
    func syncEmployeeRecords() {
        print("Syncing offline records for employee")
        Thread.sleep(forTimeInterval: 2)
        print("Syncing completed ----------")
    }
}

struct Department {
    func syncOfflineDepartmentRecords() {
        print("Syncing offline records for department")
        Thread.sleep(forTimeInterval: 2)
        print("Syncing department records ceompleted-------")
    }
}

struct SyncManager {
    
    func syncOfflineRecords() {
        
        let employeeSyncOperation = BlockOperation()
        
        employeeSyncOperation.addExecutionBlock {
            let employee = Employee()
            employee.syncEmployeeRecords()
        }
        
        let departmentSyncOperation = BlockOperation()
        
        departmentSyncOperation.addExecutionBlock {
            let department = Department()
            department.syncOfflineDepartmentRecords()
        }
        
        // Department has dependency on employee
        departmentSyncOperation.addDependency(employeeSyncOperation)
        
        //Employee has dependency on department
        employeeSyncOperation.addDependency(departmentSyncOperation)
        
        
        let operationQue = OperationQueue()
        operationQue.addOperation(employeeSyncOperation)
        operationQue.addOperation(departmentSyncOperation)
        
    }
    
}

let syncObj = SyncManager()
syncObj.syncOfflineRecords()

*/

/*
DispatchQueue.global().sync {
    print("Synchronous task")
}

DispatchQueue.global().async {
    print("Synchronous task")
}
*/

// Part 1:
// create 3 operations:
// OP1, OP2, OP3 which prints something with a 3 second delay
// OP2 -> OP1
// OP1 -> OP3
// add them to the operation queue and print output to the console

struct OP1 {
    func op1() {
        print("This is operation 1")
        Thread.sleep(forTimeInterval: 3)
        print("Operation 1 completed ----------------------")
    }
}

struct OP2 {
    func op2() {
        print("This is operation 2")
        Thread.sleep(forTimeInterval: 3)
        print("Operation 2 completed ----------------------")
    }
}

struct OP3 {
    func op3() {
        print("This is operation 3")
        Thread.sleep(forTimeInterval: 3)
        print("Operation 3 completed ----------------------")
    }
}

struct SyncManager {
    func doSomething() {
        
        let operator1 = BlockOperation()
        operator1.addExecutionBlock {
            let operatorForOperator1 = OP1()
            operatorForOperator1.op1()
        }
        
        let operator2 = BlockOperation()
        operator2.addExecutionBlock {
            let operatorForOperator2 = OP2()
            operatorForOperator2.op2()
        }
        
        let operator3 = BlockOperation()
        operator3.addExecutionBlock {
            let operatorForOperator3 = OP3()
            operatorForOperator3.op3()
        }
        
        operator3.addDependency(operator1)
        operator1.addDependency(operator2)
        
        let operationQue = OperationQueue()
        operationQue.addOperation(operator1)
        operationQue.addOperation(operator2)
        operationQue.addOperation(operator3)
        
    }
    
}

let syncObj = SyncManager()
syncObj.doSomething()

//struct Task1 <Success, Failure> where Failure : Error {
//    func doSomething1() {
//        print("This is Task1")
//    }
//}
//
//struct Task2<Success, Failure> where Failure : Error {
//    func doSomething2() {
//        print("This is Task2")
//    }
//}

// Create 2 tasks and run them on DispatchQueue asynchronously

DispatchQueue.global().async {
    print("Task 1")
}

DispatchQueue.global().async {
    print("Task 2")
}
